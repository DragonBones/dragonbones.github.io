SkeletonAnimationLibraryJS
==========================

http://dragonbones.github.io/  

In this project you can find the JavaScript source code of DragonBones library, which is a framework support rendering characters with skeleton animation by parsing assets exported from [SkeletonAnimationDesignPanel](https://github.com/DragonBones/SkeletonAnimationDesignPanel).

There are some demos in [SkeletonAnimationDemos](https://github.com/DragonBones/SkeletonAnimationDemos) project, which can guild you how to use the library  

**All things you need to download can be found [here](http://dragonbones.github.io/download.html)**  

Copyright 2012-2013 the DragonBones Team