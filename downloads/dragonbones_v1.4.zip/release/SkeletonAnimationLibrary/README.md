Skeleton Animation Framework
========

This is a 2D skeleton animation framwork. It's defined for common 2D display engines so you can easily extend it. Now it supports the Flash Runtime's Display List System and the Starling framework. It's high performance, flexible and memory-saving. To simplify the work flow, we aslo provide a plug-in for FLash Pro which can help you to build these animations. You can get it from https://github.com/DragonBones/SkeletonDesignPanel.

These are some demos for a quick view:

http://akdcl.sinaapp.com/example.html
http://dragonbones.github.com


For more information, please visit:
https://github.com/DragonBones/SkeletonAnimationFramework/wiki

Copyright 2012 The DragonBones Team